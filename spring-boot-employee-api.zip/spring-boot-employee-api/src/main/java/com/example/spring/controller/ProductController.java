package com.example.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.entity.Product;
import com.example.spring.repository.ProductRepository;
import com.example.spring.service.ProductService;



@RestController
public class ProductController {
	
	
	@Autowired
	ProductRepository productRepo;
	
@Autowired	
private ProductService productService;


@PostMapping ("/save")
public Product saveProduct(@Validated @RequestBody Product product)
{
	return productService.saveProduct(product);
}

@GetMapping("/products")
public List<Product> fetchfetchProducteList()
{
	return productService.fetchProductList();
	

}


@PostMapping("/add")
public Product createProduct(@RequestBody Product product) {
	return productService.saveProduct(product);
}


}










