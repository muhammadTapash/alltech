package com.example.spring.service;

import com.example.spring.entity.Product
;
import java.util.List;


public interface ProductService {
	
	Product saveProduct(Product product);
	
	List<Product>fetchProductList();

}
