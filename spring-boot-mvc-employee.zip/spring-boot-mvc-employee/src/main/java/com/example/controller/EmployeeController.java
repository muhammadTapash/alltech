package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.entity.Employee;
import com.example.repository.EmployeeRepository;






@Controller
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepo;
	
	@RequestMapping("/employee")
	public String home(Model model)
	{
		model.addAttribute("emoployee", employeeRepo.findAll());
		return "employee";
	}
	
	@PostMapping("/saveEmployee")
	public String createEmployee(@ModelAttribute("employee") Employee theEmployee)
	{
		employeeRepo.save(theEmployee);
		return "redirect:/employee";
	}
	
	
	@RequestMapping("/h1")
	public String addEmployee(Model model)
	{
		model.addAttribute("employee",new Employee());
		return "add";
		
	}
}
